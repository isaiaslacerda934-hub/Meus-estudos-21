package br.com.meucontroleestudos

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat

class StudyService : Service() {
    private val channel = "study_timer"
    private var active = false
    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val subject = intent.getStringExtra(EXTRA_SUBJECT) ?: "Estudos"
                val startAt = intent.getLongExtra(EXTRA_START, System.currentTimeMillis())
                active = true
                startForeground(NOTIFICATION_ID, buildNotification(subject, startAt, true))
            }
            ACTION_PAUSE -> {
                val subject = intent.getStringExtra(EXTRA_SUBJECT) ?: "Estudos"
                active = false
                val n = buildNotification(subject, 0L, false, "Cronômetro pausado")
                startForeground(NOTIFICATION_ID, n)
            }
            ACTION_STOP -> { active = false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_STICKY
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "Cronômetro de estudos", NotificationManager.IMPORTANCE_LOW).apply { description = "Mostra quando o cronômetro de estudos está ativo" })
        }
    }
    private fun buildNotification(subject: String, startAt: Long, running: Boolean, status: String? = null): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val b = NotificationCompat.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(if (running) "Estudando: $subject" else subject)
            .setContentText(status ?: "Cronômetro em segundo plano")
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH).setPriority(NotificationCompat.PRIORITY_LOW)
        if (running) b.setUsesChronometer(true).setWhen(System.currentTimeMillis() - (System.currentTimeMillis() - startAt))
        return b.build()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object {
        const val ACTION_START = "br.com.meucontroleestudos.START"
        const val ACTION_PAUSE = "br.com.meucontroleestudos.PAUSE"
        const val ACTION_STOP = "br.com.meucontroleestudos.STOP"
        const val EXTRA_SUBJECT = "subject"
        const val EXTRA_START = "startAt"
        const val NOTIFICATION_ID = 71
    }
}
