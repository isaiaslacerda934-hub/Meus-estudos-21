package br.com.meucontroleestudos

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(StudyBridge(), "AndroidStudy")
        setContentView(web)
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html") else web.restoreState(savedInstanceState)
    }
    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    inner class StudyBridge {
        @JavascriptInterface fun startStudy(subject: String, startAt: Long) {
            val i = Intent(this@MainActivity, StudyService::class.java).apply {
                action = StudyService.ACTION_START
                putExtra(StudyService.EXTRA_SUBJECT, subject)
                putExtra(StudyService.EXTRA_START, startAt)
            }
            if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this@MainActivity, i) else startService(i)
        }
        @JavascriptInterface fun pauseStudy(subject: String) {
            startService(Intent(this@MainActivity, StudyService::class.java).apply { action = StudyService.ACTION_PAUSE; putExtra(StudyService.EXTRA_SUBJECT, subject) })
        }
        @JavascriptInterface fun stopStudy() { startService(Intent(this@MainActivity, StudyService::class.java).apply { action = StudyService.ACTION_STOP }) }
    }
}
